<?php
include('../../../config/net.php'); // Incluye tu conexión PDO aquí
include('../../../modules/FPDF/fpdf.php');

// Función para formatear la fecha en letras
function formatearFechaEnLetras($fecha) {
    $meses = [
        1 => 'enero', 2 => 'febrero', 3 => 'marzo', 4 => 'abril', 5 => 'mayo', 6 => 'junio',
        7 => 'julio', 8 => 'agosto', 9 => 'septiembre', 10 => 'octubre', 11 => 'noviembre', 12 => 'diciembre'
    ];

    $dia = date('j', strtotime($fecha)); // Día sin ceros a la izquierda
    $mes = $meses[date('n', strtotime($fecha))]; // Mes en letras
    $anio = date('Y', strtotime($fecha)); // Año completo

    return "$dia de $mes de $anio";
}

// Función para obtener el nombre del catálogo (marca o tipo) según el ID
function obtenerNombreCatalogo($id, $net_rrhh) {
    $sql = "SELECT * FROM catalogue WHERE id = :id";
    $stmt = $net_rrhh->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Si existe el resultado, devolvemos el nombre, de lo contrario, un mensaje de error
    $catalogo = $stmt->fetch(PDO::FETCH_ASSOC);
    return $catalogo ? utf8_decode($catalogo['value']) : 'No encontrado';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user'];
    $asunto = $_POST['textInput'];
    $fecha_creacion = formatearFechaEnLetras(date('Y-m-d'));

    $marca = isset($_POST['marca']) ? $_POST['marca'] : [];
    $tipo = isset($_POST['tipo']) ? $_POST['tipo'] : [];
    $modelo = isset($_POST['modelo']) ? $_POST['modelo'] : [];
    $serie = isset($_POST['serie']) ? $_POST['serie'] : [];

    // Consulta para obtener el nombre completo del usuario
    $sql_user = "SELECT CONCAT(name1, ' ', name2, ' ', lastname1, ' ', lastname2) as full_name FROM employee WHERE id = :user_id";
    $stmt_user = $net_rrhh->prepare($sql_user);
    $stmt_user->bindParam(':user_id', $user_id);
    $stmt_user->execute();
    $user_data = $stmt_user->fetch(PDO::FETCH_ASSOC);
    $user_name = $user_data ? utf8_decode($user_data['full_name']) : 'Usuario no encontrado';

    // CONSULTA DEL PUESTO
    $sql_puesto = "SELECT p.position FROM employee as e 
                   INNER JOIN workarea_positions_assignment as wpa ON wpa.idemployee = e.id 
                   INNER JOIN workarea_positions as p ON p.id = wpa.idposition 
                   WHERE e.id = :user_id AND wpa.enddate = '0000-00-00'";
    $stmt_puesto = $net_rrhh->prepare($sql_puesto);
    $stmt_puesto->bindParam(':user_id', $user_id);
    $stmt_puesto->execute();
    $puesto_data = $stmt_puesto->fetch(PDO::FETCH_ASSOC);
    $puesto = $puesto_data ? utf8_decode($puesto_data['position']) : 'Puesto no encontrado';

    if (isset($_FILES['signatureImage']) && $_FILES['signatureImage']['error'] === UPLOAD_ERR_OK) {
        $imgTmpName = $_FILES['signatureImage']['tmp_name'];
        $imgName = 'firma_' . uniqid() . '.png';
        $imgPath = '../img_firmas/' . $imgName;

        if (move_uploaded_file($imgTmpName, $imgPath)) {
            try {
                // Inserción del memorándum en la base de datos
                $sql = "INSERT INTO inventory_memos (usuario, asunto, fecha_creacion, img) VALUES (:user, :asunto, :fecha_creacion, :img)";
                $stmt = $net_rrhh->prepare($sql);
                
                $stmt->bindParam(':user', $user_id);
                $stmt->bindParam(':asunto', $asunto);
                $stmt->bindParam(':fecha_creacion', $fecha_creacion);
                $stmt->bindParam(':img', $imgName);
                
                // Ejecutar la consulta de inserción
                $stmt->execute();

                // Ahora obtenemos el ID generado
                $memo_id = $net_rrhh->lastInsertId();

                // Generar el PDF con el memo_id correcto y la firma
                generarPDF($user_name, $puesto, $asunto, $marca, $tipo, $modelo, $serie, $memo_id, $imgPath, $fecha_creacion, $net_rrhh);

            } catch (PDOException $e) {
                echo "Error al guardar el memorándum: " . $e->getMessage();
            }
        } else {
            echo "Error al subir la firma.";
        }
    } else {
        echo "No se recibió una firma válida.";
    }
}

function generarPDF($user_name, $puesto, $asunto, $marca, $tipo, $modelo, $serie, $memo_id, $imgPath, $fecha_creacion, $net_rrhh) {
    // Crear un nuevo PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    
    // Agregar las imágenes al encabezado
    // Ruta de las imágenes que tú proporcionarás
    $imageLeft = '../recursos_inventory/Logo Fusalmo 2.png'; // Cambia a la ruta correcta
    $imageRight = '../recursos_inventory/PROPUESTA DE VALOR.png'; // Cambia a la ruta correcta
    
    // Colocar la primera imagen (izquierda)
    $pdf->Image($imageLeft, 10, 10, 50); // Ajusta la posición y el tamaño

    // Colocar la segunda imagen (derecha)
    $pdf->Image($imageRight, 150, 10, 50); // Ajusta la posición y el tamaño

    // Mover el cursor hacia abajo para comenzar el contenido del documento
    $pdf->Ln(30); // Ajusta este valor según el tamaño de las imágenes


    // Configuración general de la fuente
    $pdf->SetFont('Arial', 'B', 9);
    
    // Título "Para:"
    $pdf->Cell(25, 6, 'PARA:', 0, 0, 'L'); // Ajustamos la altura de la celda para hacer más compacto el espacio vertical
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->Cell(0, 6, strtoupper(utf8_decode($user_name)), 0, 1);  // Nombre en mayúsculas

    // Puesto del usuario (más pegado al nombre)
    $pdf->SetFont('Arial', '', 9);
    $pdf->Cell(25, 5, '', 0, 0, 'L'); // Esto crea un margen a la izquierda para que el texto no quede pegado al borde
    $pdf->Cell(0, 5, strtoupper(utf8_decode($puesto)), 0, 1); // Colocar el puesto justo debajo del nombre

    // Imagen de la firma a la par del nombre
    if (file_exists($imgPath)) {
        $pdf->Image($imgPath, 120, 30, 20, 10); // Ajusta la posición y tamaño según tus necesidades
    }

    // Título "De:" y el nombre de Andrés
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->Cell(25, 10, 'DE:', 0, 0, 'L'); // Ajusta el margen izquierdo
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->MultiCell(0, 6, strtoupper('ANDRES RENE VELASQUEZ RODRIGUEZ'), 0, 'L'); // Nombre de Andrés
    $pdf->Cell(25, 5, '', 0, 0, 'L');
    $pdf->SetFont('Arial', '', 9); // Esto crea el margen a la izquierda
    $pdf->MultiCell(0, 5, strtoupper('TECNICO DE SOPORTE IT JR.'), 0, 'L'); // Puesto de Andrés

    // Título "VoBo:" y el nombre de Roberto
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->Cell(25, 10, 'VoBo:', 0, 0, 'L'); // Alineado con el margen izquierdo
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->MultiCell(0, 6, strtoupper('JOSE ROBERTO OCHOA MEDRANO'), 0, 'L');
    $pdf->SetFont('Arial', '', 9); // Nombre de Roberto
    $pdf->Cell(25, 5, '', 0, 0, 'L'); // Crea el margen izquierdo para el puesto
    $pdf->MultiCell(0, 5, strtoupper('COORDINADOR DE INFRAESTRUCTURA Y DESARROLLO DE SOFTWARE'), 0, 'L'); // Puesto de Roberto

    // Asunto en azul y subrayado
    $pdf->Ln(5);  // Espacio adicional
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->Cell(25, 10, 'ASUNTO:', 0, 0, 'L');
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetTextColor(0, 0, 255);  // Azul
    $pdf->Cell(0, 10, utf8_decode($asunto), 0, 1);
    $pdf->SetTextColor(0, 0, 0);  // Volver al color negro

    // Fecha
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->Cell(25, 10, 'FECHA:', 0, 0, 'L');
    $pdf->SetFont('Arial', '', 9);
    $pdf->Cell(0, 10, strtoupper(utf8_decode($fecha_creacion)), 0, 1);

    // Línea divisoria
    $pdf->Ln(5);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(5);

    // Descripción del recurso tecnológico
    $pdf->SetFont('Arial', '', 9);
    $pdf->Cell(0, 5, utf8_decode('Ante la requisición del material tecnológico se realiza la entrega del siguiente recurso tecnológico'), 0, 1);
    $pdf->Cell(0, 5, utf8_decode('con su respectivo cargador y detalle:'), 0, 1);

    // Tabla
    $pdf->Ln(5);
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetFillColor(0, 0, 0);  // Fondo negro
    $pdf->SetTextColor(255, 255, 255);  // Texto blanco

    // Cabecera de la tabla
    $pdf->Cell(40, 10, 'MARCA', 1, 0, 'C', true);
    $pdf->Cell(40, 10, 'TIPO DE EQUIPO', 1, 0, 'C', true);
    $pdf->Cell(40, 10, 'MODELO', 1, 0, 'C', true);
    $pdf->Cell(60, 10, utf8_decode('NÚMERO DE SERIAL'), 1, 1, 'C', true);

    // Relleno de la tabla con los datos (consulta de nombres)
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetFillColor(169, 169, 169);  // Fondo gris claro
    $pdf->SetTextColor(0, 0, 0);  // Texto negro
    for ($i = 0; $i < count($marca); $i++) {
        $nombre_marca = obtenerNombreCatalogo($marca[$i], $net_rrhh);
        $nombre_tipo = obtenerNombreCatalogo($tipo[$i], $net_rrhh);

        $pdf->Cell(40, 10, strtoupper($nombre_marca), 1, 0, 'C');
        $pdf->Cell(40, 10, strtoupper($nombre_tipo), 1, 0, 'C');
        $pdf->Cell(40, 10, strtoupper($modelo[$i]), 1, 0, 'C');
        $pdf->Cell(60, 10, strtoupper($serie[$i]), 1, 1, 'C');
        $pdf->Ln();
    }

    // Guardar el PDF en el servidor
    $filePath = '../memorandums/memorandum_' . $memo_id . '.pdf';
    $pdf->Output('F', $filePath);

    // Redirigir para descargar el PDF
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="memorandum_' . $memo_id . '.pdf"');
    header('Content-Length: ' . filesize($filePath));

    // Leer el archivo y enviarlo al navegador
    readfile($filePath);

    // Terminar el script después de enviar el archivo
    exit();
}
